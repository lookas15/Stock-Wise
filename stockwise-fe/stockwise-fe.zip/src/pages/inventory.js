import { renderLayout } from '../components/layout.js';
import swal from 'sweetalert';

export function renderInventoryPage() {
  const app = document.getElementById('app');

  async function loadInventoryPrediction() {
    try {
      const response = await fetch('http://localhost:3000/api/prediction/compare');
      if (!response.ok) throw new Error('Failed to fetch prediction data.');
      const data = await response.json();

      // Render each row
      const rows = data.map(item => {
        const statusColor =
          item.status === 'understock' ? 'text-red-600' :
          item.status === 'overstock' ? 'text-yellow-600' :
          item.status === 'balanced' ? 'text-green-600' :
          'text-gray-600';

        return `
          <tr class="border-t">
            <td class="py-2 px-2">${item.pizza_id}</td>
            <td class="py-2 px-2">${item.predicted}</td>
            <td class="py-2 px-2">${item.actual}</td>
            <td class="py-2 px-2 ${statusColor} font-semibold">${item.status}</td>
          </tr>
        `;
      }).join('');

      const content = `
        <h1 class="text-3xl font-semibold mb-6">📦 Inventory</h1>

        <div class="bg-white shadow-md rounded-lg p-6">
          <h2 class="text-lg font-semibold mb-4">Predicted vs Actual Inventory</h2>

          <div class="overflow-x-auto">
            <table class="w-full table-auto text-left border">
              <thead class="bg-gray-100 text-sm text-gray-700 uppercase border-b">
                <tr>
                  <th class="py-2 px-2">Pizza ID</th>
                  <th class="py-2 px-2">Predicted</th>
                  <th class="py-2 px-2">Actual</th>
                  <th class="py-2 px-2">Status</th>
                </tr>
              </thead>
              <tbody>
                ${rows}
              </tbody>
            </table>
          </div>

          <div class="mt-6 flex gap-4">
            <button id="add-btn" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">➕ Add</button>
            <button id="edit-btn" class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">✏️ Edit</button>
            <button id="remove-btn" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">🗑️ Remove</button>
          </div>

          <p class="mt-6 text-sm text-yellow-700">
            ⚠️ Inventory modification is disabled in this version. Please contact an administrator or use Supabase.
          </p>
        </div>
      `;

      app.innerHTML = renderLayout(content);

      // SweetAlert placeholders
      const alertUnavailable = () =>
        swal('🔒 Unavailable', 'This function is not available in this version.', 'info');

      document.getElementById('add-btn')?.addEventListener('click', alertUnavailable);
      document.getElementById('edit-btn')?.addEventListener('click', alertUnavailable);
      document.getElementById('remove-btn')?.addEventListener('click', alertUnavailable);

    } catch (error) {
      const errorContent = `
        <h1 class="text-3xl font-semibold mb-4">📦 Inventory</h1>
        <p class="text-red-600 font-medium">❌ Failed to load inventory data:</p>
        <pre class="bg-red-50 text-red-800 mt-4 p-4 rounded border border-red-200">${error.message}</pre>
      `;
      app.innerHTML = renderLayout(errorContent);
    }
  }

  loadInventoryPrediction();
}
